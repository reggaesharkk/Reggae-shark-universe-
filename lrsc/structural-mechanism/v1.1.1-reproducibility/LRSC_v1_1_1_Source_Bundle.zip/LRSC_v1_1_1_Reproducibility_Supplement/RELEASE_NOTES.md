# Release notes — LRSC v1.1.1

A separate reproducibility supplement for the M=99, k_idx=49, theta=0.08, A=0.50 single-step compression benchmark. Includes PDF, Python driver, C++17 exhaustive enumerator, and run output.

The source verifies all subsets at every exact cardinality K=1 through 10 and directly verifies one passing K=11 witness. It reproduces K_0.001=11 in IEEE double precision for this stated benchmark. This is not an interval-arithmetic or exact-rational proof.

The historical v1.1 files, frozen v1.2 theorem, and DOI 10.17605/OSF.IO/NM5BW are unchanged.
