"""
High-precision (mpmath, 50 digits) numerical cross-check of two subsets.
Recomputes the K=10 subset selected by the double-precision exhaustive search
and one K=11 witness, then reports differences from the double-precision values
and each residual's margin relative to 0.001. mpmath here is not an outward-
rounded interval implementation. These differences are not certified error
bounds, and this script does not re-evaluate the other K<=10 subsets.
"""
import mpmath as mp
mp.mp.dps = 50

M, K_IDX, THETA, A = 99, 49, mp.mpf('0.08'), mp.mpf('0.50')

def build_mp():
    X = [mp.mpf(1) + A*mp.cos(2*mp.pi*K_IDX*i/M) for i in range(M)]
    left = [X[(i-1) % M] for i in range(M)]
    right = [X[(i+1) % M] for i in range(M)]
    j = [X[i] - min(left[i], X[i], right[i]) for i in range(M)]
    stress = [mp.mpf('0.5')*((X[i]-left[i])**2 + (X[i]-right[i])**2) for i in range(M)]
    mask = [mp.mpf(1) if stress[i] > THETA else mp.mpf(0) for i in range(M)]

    def dft(x):
        out = []
        for q in range(M):
            s = mp.mpc(0)
            for i in range(M):
                s += x[i]*mp.e**(-2j*mp.pi*q*i/M)
            out.append(s/M)
        return out

    m_hat = dft(mask)
    j_hat = dft(j)
    my = [mask[i]*j[i] for i in range(M)]
    y_hat = dft(my)

    stencil = [mp.cos(2*mp.pi*q/M) - 1 for q in range(M)]
    E = [stencil[q]*y_hat[q] for q in range(M)]

    V = [[mp.mpc(0)]*M for _ in range(50)]
    for q in range(M):
        V[0][q] = stencil[q]*(j_hat[0]*m_hat[q])
    for r in range(1, 50):
        rc = M - r
        for q in range(M):
            V[r][q] = stencil[q]*(j_hat[r]*m_hat[(q-r) % M] + j_hat[rc]*m_hat[(q-rc) % M])
    return E, V

def resid(E, V, subset):
    acc = mp.mpf(0)
    normE = mp.sqrt(sum(abs(e)**2 for e in E))
    for q in range(len(E)):
        d = E[q] - sum(V[r][q] for r in subset)
        acc += abs(d)**2
    return mp.sqrt(acc)/normE

if __name__ == "__main__":
    E, V = build_mp()
    K10 = (0,1,42,43,44,45,46,47,48,49)
    K11 = (0,1,3,42,43,44,45,46,47,48,49)
    e10 = resid(E, V, K10)
    e11 = resid(E, V, K11)
    print("K10 (50 dps):", mp.nstr(e10, 30))
    print("K11 (50 dps):", mp.nstr(e11, 30))
    print("double-precision K10 value: 0.0010398206190990497 (this companion) / 0.0010398206190990441 (bundle)")
    print("double-precision K11 value: 0.00096236912766441347 (bundle)")
    print("50-digit vs double abs diff, K10:", mp.nstr(abs(e10 - mp.mpf('0.0010398206190990497')), 5))
    print("50-digit vs double abs diff, K11:", mp.nstr(abs(e11 - mp.mpf('0.00096236912766441347')), 5))
    margin_to_threshold_K10 = e10 - mp.mpf('0.001')
    margin_to_threshold_K11 = mp.mpf('0.001') - e11
    print("K10 margin ABOVE 0.001 threshold:", mp.nstr(margin_to_threshold_K10, 10))
    print("K11 margin BELOW 0.001 threshold:", mp.nstr(margin_to_threshold_K11, 10))
