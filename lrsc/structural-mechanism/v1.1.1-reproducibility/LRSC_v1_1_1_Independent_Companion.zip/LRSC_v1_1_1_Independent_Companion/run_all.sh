#!/bin/sh
# Exact commands to reproduce this companion verification from scratch.
set -e
python3 build_operator.py
gcc -O3 -std=c11 -Wall -o lrsc_independent_search search.c -lm
./lrsc_independent_search channels.bin 10 | tee VERIFICATION_OUTPUT_independent.txt
python3 highprec_borderline.py | tee HIGH_PRECISION_BORDERLINE_CHECK.txt
