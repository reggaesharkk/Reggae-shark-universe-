PRINCE UPADHYAY — ALL 4 RESEARCH PROGRAMS
Final paper archive assembled 22 September 2026
Author: Prince Upadhyay
Affiliation: Independent Research

01 — SELF-REFERENTIAL PROCESSING
- Self-Referential Processing Pre-Registration v8.6.3

02 — PSI BENCHMARK
- Operationalizing Self-Modeling Organization

03 — PHYSICS AND RECURSIVE COSMOLOGY
- A Recursive Information-Consciousness Cosmology
- Information-Theoretic Framework for Emergent Spacetime Dynamics
- Gate 0 Observer-Horizon Bridge Audit
- Physics Consolidated Research Paper (N3DQU branch)
- Appendix A v1.1 Dynamical Sector
- Appendix A v1.3 Hopf Hypersurface Audit (corrected)
- Appendix A v1.4 Analytic Positivity Theorem
- Appendix A v1.4.1 Author Errata and Verification Patch

04 — LRSC
- LRSC Single-Step Spectral Certificate v1.0
- LRSC Structural Mechanism Audit v1.1
- LRSC Odd-Ring Spectral Rank Theorem v1.2

Archival note:
Frozen/versioned releases are kept as historical records. Later papers do not silently overwrite earlier versions.
